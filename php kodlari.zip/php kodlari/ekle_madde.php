<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

<title>Sign Our Guestbook</title>

<link rel="stylesheet" href="css/style.css" />

<link rel="stylesheet" href="css/sign.css" />

	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"></script>
	
	
	
</head>

<body>

<?php
	$host="localhost"; //Add your SQL Server host here
	$user="kulladi"; //SQL Username
	$pass="passwd"; //SQL Password
	$dbname="dbname"; //SQL Database Name
	$con=mysqli_connect($host,$user,$pass,$dbname);
	if (mysqli_connect_errno($con))
	{
		echo "<h1>Failed to connect to MySQL: " . mysqli_connect_error() ."</h1>";
	}
	
	
    $frage=$_POST['frage'];
    $antwort=$_POST['antwort'];


	$sql="INSERT INTO wiso(frage,antwort) VALUES('$frage','$antwort')";
	
	
	
	if (!mysqli_query($con,$sql))
	{
		die('Error: ' . mysqli_error($con));
	}
	else
		echo "veri eklendi. <br>";

echo '<center> <a href="/fragen_wiso/index.php"><button type="button" class="btn btn-primary btn-lg"> Index wiso </button> </a> </a>
		</center>';
echo '<center> <a href="/fragen/index.php"><button type="button" class="btn btn-primary btn-lg"> Index </button> </a> </a>
		</center>';
	
	
	
	
	mysqli_close($con);
?>
</body>
</html>
	