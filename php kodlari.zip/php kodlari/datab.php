<?php


error_reporting(0);
$host 	= 'localhost'; //host bilgisi
$user 	= 'kullaniciadi'; //kullanıcı adı
$pass 	= 'password'; //sifre
$db		= 'dbname'; //veritabanı ismi

$table = "tabloadi";

			
$baglan = mysqli_connect($host, $user, $pass, $db) or die (mysqli_Error());
mysqli_query($baglan,"SET CHARACTER SET 'utf8'");
mysqli_query($baglan,"SET NAMES 'utf8'");

?>