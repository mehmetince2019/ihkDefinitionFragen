<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />


<link rel="stylesheet" href="css/style.css" />

<link rel="stylesheet" href="css/sign.css" />

	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"></script>
	
	
	
</head>

<body>

    <div id="menu">
    <hr/>
    <ul id="mainMenu">
	   <center> <a href="/fragen/index.php"><button type="button" class="btn btn-primary btn-lg"> Index </button> </a> </a>
		</center>
      
        
    </ul>
    <hr/>
    </div>
    <center>
    <div id="content">
        
		
   		
		<form name="guest" method="post" action="ekle_madde.php">
		            
			
			<textarea name="frage" rows="5" cols="30"> </textarea> <br/>
                
          <textarea name="antwort" rows="5" cols="30"> </textarea> <br/>
               
        
   
			
       <center> <input type="submit" button type="button" class="btn btn-primary btn-lg"  </button>   </a>
			</center>
		</form>
    </div>
</center>
   
    <hr/>
   
    </div>
</body>
</html>






